# Copyright (C) 2020-2025 The LiteGapps Project
# by wahyu6070
# permissions.sh (run by update-binary)
#


